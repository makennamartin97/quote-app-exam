from django.apps import AppConfig


class PythonexamAppConfig(AppConfig):
    name = 'pythonexam_app'
